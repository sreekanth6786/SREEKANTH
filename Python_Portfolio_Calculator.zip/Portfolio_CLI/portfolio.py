def show_portfolio():
    print("===================================")
    print("      DEVARINTI SREEKANTH")
    print("===================================")
    print("📧 Email     : sreekanth@example.com")
    print("🎓 Education : B.Tech in Computer Science")
    print("💼 Skills    : Python, Web Development, Machine Learning")
    print("📁 Projects  :")
    print("   1. Portfolio Website")
    print("   2. Stock Price Prediction Using ML")
    print("   3. To-Do List App")
    print("🔗 LinkedIn  : linkedin.com/in/sreekanth")
    print("===================================")

if __name__ == "__main__":
    show_portfolio()
